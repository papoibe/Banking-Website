/**
 * Vietcombank Login Form Functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('txtTenDN');
    const passwordInput = document.getElementById('txtMatKhau');
    const togglePasswordBtn = document.querySelector('.toggle-password');
    
    // Toggle password visibility
    if (togglePasswordBtn) {
        togglePasswordBtn.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            // Toggle icon
            const icon = this.querySelector('i');
            icon.classList.toggle('fa-eye');
            icon.classList.toggle('fa-eye-slash');
        });
    }
    
    // Handle form submission
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();
            
            // Basic validation
            if (!username) {
                showError(usernameInput, 'Vui lòng nhập tên đăng nhập');
                return;
            } else {
                removeError(usernameInput);
            }
            
            if (!password) {
                showError(passwordInput, 'Vui lòng nhập mật khẩu');
                return;
            } else {
                removeError(passwordInput);
            }
            
            // Check credentials (demo only - would be replaced with proper authentication)
            if (username === 'admin' && password === 'admin123') {
                showSuccess('Đăng nhập thành công');
                
                // Redirect after a short delay
                setTimeout(() => {
                    window.location.href = 'diendan.html';
                }, 1500);
            } else {
                showError(passwordInput, 'Tên đăng nhập hoặc mật khẩu không đúng');
            }
        });
    }
    
    /**
     * Show error message for an input field
     * @param {HTMLElement} input - The input element
     * @param {string} message - Error message to display
     */
    function showError(input, message) {
        const formGroup = input.closest('.form-group');
        
        // Remove existing error message if any
        removeError(input);
        
        // Add error class
        formGroup.classList.add('error');
        
        // Create error message element
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        
        // Append error message
        formGroup.appendChild(errorElement);
        
        // Highlight input
        input.style.borderColor = '#e74c3c';
    }
    
    /**
     * Remove error message from an input field
     * @param {HTMLElement} input - The input element
     */
    function removeError(input) {
        const formGroup = input.closest('.form-group');
        const errorElement = formGroup.querySelector('.error-message');
        
        // Remove error class
        formGroup.classList.remove('error');
        
        // Remove error message if exists
        if (errorElement) {
            formGroup.removeChild(errorElement);
        }
        
        // Reset input style
        input.style.borderColor = '';
    }
    
    /**
     * Display success message
     * @param {string} message - Success message to display
     */
    function showSuccess(message) {
        // Check if notification exists, remove if yes
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            document.body.removeChild(existingNotification);
        }
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification success';
        
        // Create notification content
        const content = document.createElement('div');
        content.className = 'notification-content';
        content.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        `;
        
        // Append content to notification
        notification.appendChild(content);
        
        // Append notification to body
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Auto remove notification
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    /**
     * Add CSS for notifications
     */
    function addNotificationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .error-message {
                color: #e74c3c;
                font-size: 12px;
                margin-top: 5px;
            }
            
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                background-color: #fff;
                border-radius: 4px;
                box-shadow: 0 3px 15px rgba(0, 0, 0, 0.2);
                transform: translateX(120%);
                transition: transform 0.3s ease-out;
                z-index: 1000;
            }
            
            .notification.show {
                transform: translateX(0);
            }
            
            .notification-content {
                display: flex;
                align-items: center;
            }
            
            .notification-content i {
                margin-right: 10px;
                font-size: 20px;
            }
            
            .notification.success {
                border-left: 4px solid #2ecc71;
            }
            
            .notification.success i {
                color: #2ecc71;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Add notification styles
    addNotificationStyles();
});