/**
 * Main JavaScript functionality for Vietcombank website
 */
document.addEventListener('DOMContentLoaded', function() {
    // Sticky header
    const header = document.querySelector('.header');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky');
            }
        });
    }
    
    // Hero slider functionality
    initializeSlider();
    
    // Initialize dropdown menus if they exist
    initializeDropdowns();
    
    // Initialize mobile menu if it exists
    initializeMobileMenu();
    
    // Initialize promotion list scrolling marquee
    initializePromotionScroll();
    
    // Initialize popular news slider if it exists
    initializePopularNewsSlider();
});

/**
 * Initialize image slider
 */
function initializeSlider() {
    const slides = document.querySelectorAll('.slide');
    const dotItems = document.querySelectorAll('.dot');
    const slidesContainer = document.querySelector('.slides');
    
    if (!slides.length || !dotItems.length || !slidesContainer) return;
    
    let currentIndex = 0;
    let slideInterval;
    
    // Set initial position for each slide
    slides.forEach((slide, index) => {
        slide.style.transform = `translateX(${index * 100}%)`;
    });
    
    // Initialize dots
    dotItems.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            clearInterval(slideInterval);
            goToSlide(index);
            startSlideInterval();
        });
    });
    
    // Function to go to a specific slide
    function goToSlide(index) {
        // Update current index
        currentIndex = index;
        
        // Update slides position
        slides.forEach((slide, i) => {
            slide.style.transform = `translateX(${(i - index) * 100}%)`;
        });
        
        // Update dots
        dotItems.forEach(dot => dot.classList.remove('active'));
        dotItems[index].classList.add('active');
    }
    
    // Function to go to the next slide
    function nextSlide() {
        currentIndex = (currentIndex + 1) % slides.length;
        goToSlide(currentIndex);
    }
    
    // Start automatic sliding
    function startSlideInterval() {
        slideInterval = setInterval(nextSlide, 5000);
    }
    
    // Initialize
    goToSlide(0);
    startSlideInterval();
    
    // Pause slider on hover
    slidesContainer.addEventListener('mouseenter', () => {
        clearInterval(slideInterval);
    });
    
    slidesContainer.addEventListener('mouseleave', () => {
        startSlideInterval();
    });
    
    // Swipe functionality for mobile
    let touchStartX = 0;
    let touchEndX = 0;
    
    slidesContainer.addEventListener('touchstart', e => {
        touchStartX = e.changedTouches[0].screenX;
    });
    
    slidesContainer.addEventListener('touchend', e => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        
        if (touchEndX < touchStartX - swipeThreshold) {
            // Swipe left
            nextSlide();
        } else if (touchEndX > touchStartX + swipeThreshold) {
            // Swipe right
            currentIndex = (currentIndex - 1 + slides.length) % slides.length;
            goToSlide(currentIndex);
        }
    }
}

/**
 * Initialize dropdown menus
 */
function initializeDropdowns() {
    const navItems = document.querySelectorAll('.nav-menu > li');
    
    navItems.forEach(item => {
        const hasDropdown = item.querySelector('.dropdown');
        
        if (hasDropdown) {
            item.addEventListener('mouseenter', () => {
                hasDropdown.classList.add('active');
            });
            
            item.addEventListener('mouseleave', () => {
                hasDropdown.classList.remove('active');
            });
        }
    });
}

/**
 * Initialize mobile menu
 */
function initializeMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const overlay = document.createElement('div');
    overlay.className = 'mobile-menu-overlay';
    
    if (!mobileMenuBtn || !mobileMenu) return;
    
    document.body.appendChild(overlay);
    
    mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.classList.toggle('no-scroll');
    });
    
    overlay.addEventListener('click', () => {
        mobileMenu.classList.remove('active');
        overlay.classList.remove('active');
        document.body.classList.remove('no-scroll');
    });
    
    // Handle submenus in mobile menu
    const mobileSubMenuToggles = document.querySelectorAll('.mobile-menu .has-submenu > a');
    
    mobileSubMenuToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const parent = this.parentElement;
            const submenu = parent.querySelector('.submenu');
            
            if (parent.classList.contains('active')) {
                parent.classList.remove('active');
                submenu.style.maxHeight = '0px';
            } else {
                parent.classList.add('active');
                submenu.style.maxHeight = submenu.scrollHeight + 'px';
            }
        });
    });
}

/**
 * Initialize promotion list scrolling
 */
function initializePromotionScroll() {
    const promotionList = document.querySelector('.promotion-list');
    if (!promotionList) return;
    
    // Custom auto-scrolling without marquee tag
    const promotions = promotionList.querySelectorAll('a');
    let currentPos = 0;
    const scrollSpeed = 1; // pixels per frame
    
    function animateScroll() {
        currentPos -= scrollSpeed;
        
        // Reset when first item is scrolled out
        if (currentPos <= -promotions[0].offsetHeight) {
            currentPos = 0;
            // Move first item to the end
            promotionList.appendChild(promotions[0]);
        }
        
        promotionList.style.transform = `translateY(${currentPos}px)`;
        requestAnimationFrame(animateScroll);
    }
    
    // Pause on hover
    promotionList.addEventListener('mouseenter', () => {
        cancelAnimationFrame(animateScroll);
    });
    
    promotionList.addEventListener('mouseleave', () => {
        requestAnimationFrame(animateScroll);
    });
    
    // Start animation
    requestAnimationFrame(animateScroll);
}

/**
 * Initialize popular news slider
 */
function initializePopularNewsSlider() {
    const slider = document.querySelector('.popular-news-slider');
    if (!slider) return;
    
    let isDown = false;
    let startX;
    let scrollLeft;
    
    slider.addEventListener('mousedown', (e) => {
        isDown = true;
        slider.classList.add('active');
        startX = e.pageX - slider.offsetLeft;
        scrollLeft = slider.scrollLeft;
    });
    
    slider.addEventListener('mouseleave', () => {
        isDown = false;
        slider.classList.remove('active');
    });
    
    slider.addEventListener('mouseup', () => {
        isDown = false;
        slider.classList.remove('active');
    });
    
    slider.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - slider.offsetLeft;
        const walk = (x - startX) * 2; // Scroll speed multiplier
        slider.scrollLeft = scrollLeft - walk;
    });
    
    // Add auto scroll functionality
    const items = slider.querySelectorAll('.popular-item');
    let currentPos = 0;
    const itemWidth = items[0].offsetWidth + parseInt(window.getComputedStyle(items[0]).marginRight);
    
    function scrollRight() {
        currentPos++;
        if (currentPos >= items.length) {
            currentPos = 0;
            slider.scrollLeft = 0;
        } else {
            slider.scrollLeft = currentPos * itemWidth;
        }
    }
    
    // Auto scroll every 3 seconds
    let scrollInterval = setInterval(scrollRight, 3000);
    
    // Pause on hover
    slider.addEventListener('mouseenter', () => {
        clearInterval(scrollInterval);
    });
    
    slider.addEventListener('mouseleave', () => {
        scrollInterval = setInterval(scrollRight, 3000);
    });
}