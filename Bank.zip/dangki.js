/**
 * Vietcombank Register Form Functionality
 * @version 1.0.0
 * @author VCB Web Team
 */

document.addEventListener('DOMContentLoaded'), function() {
    // Cache DOM elements
    const registerForm = document.getElementById('registerForm');
    const inputs = {
        fullName: document.getElementById('txtHoTen'),
        email: document.getElementById('txtEmail'),
        year: document.getElementById('txtNam'),
        username: document.getElementById('txtTenDN'),
        password: document.getElementById('txtMatKhau'),
        confirmPassword: document.getElementById('txtNhapLaiMK')
    };
    
    const togglePasswordBtns = document.querySelectorAll('.toggle-password');
    const strengthMeter = document.querySelector('.strength-meter');
    const strengthText = document.querySelector('.strength-text');
    
    // Initialize form validation
    initPasswordToggle();
    initPasswordStrengthMeter();
    initFormValidation();
    
    /**
     * Initialize password toggle functionality
     */
    function initPasswordToggle() {
        if (!togglePasswordBtns.length) return;
        
        togglePasswordBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const passwordField = this.closest('.password-input').querySelector('input');
                const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordField.setAttribute('type', type);
                
                // Toggle icon
                const icon = this.querySelector('i');
                icon.classList.toggle('fa-eye');
                icon.classList.toggle('fa-eye-slash');
                
                // Set focus back to password field
                passwordField.focus();
            });
        });
    }
    
    /**
     * Initialize password strength meter
     */
    function initPasswordStrengthMeter() {
        if (!inputs.password || !strengthMeter || !strengthText) return;
        
        inputs.password.addEventListener('input', function() {
            const password = this.value;
            const strength = checkPasswordStrength(password);
            
            // Remove all classes
            strengthMeter.classList.remove('weak', 'medium', 'strong');
            
            if (password.length === 0) {
                strengthText.textContent = 'Độ mạnh: Chưa nhập';
            } else {
                // Add appropriate class
                strengthMeter.classList.add(strength);
                
                // Update text
                if (strength === 'weak') {
                    strengthText.textContent = 'Độ mạnh: Yếu';
                } else if (strength === 'medium') {
                    strengthText.textContent = 'Độ mạnh: Trung bình';
                } else if (strength === 'strong') {
                    strengthText.textContent = 'Độ mạnh: Mạnh';
                }
            }
        });
    }
    
    /**
     * Initialize form validation
     */
    function initFormValidation() {
        if (!registerForm) return;
        
        // Add validation for each input field on blur
        Object.values(inputs).forEach(input => {
            if (!input) return;
            
            input.addEventListener('blur', function() {
                validateInput(this);
            });
            
            // Clear error on focus
            input.addEventListener('focus', function() {
                removeError(this);
            });
        });
        
        // Form submission validation
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate all inputs
            let isValid = true;
            
            Object.values(inputs).forEach(input => {
                if (!input) return;
                if (!validateInput(input)) {
                    isValid = false;
                }
            });
            
            // Special validation for confirm password
            if (inputs.password && inputs.confirmPassword) {
                if (inputs.password.value !== inputs.confirmPassword.value) {
                    showError(inputs.confirmPassword, 'Mật khẩu nhập lại không khớp');
                    isValid = false;
                }
            }
            
            // If form is valid, submit or show success message
            if (isValid) {
                showNotification('Đăng ký thành công! Đang chuyển hướng...', 'success');
                
                // Disable form inputs while submitting
                Object.values(inputs).forEach(input => {
                    if (input) input.disabled = true;
                });
                
                // Disable submit button
                const submitBtn = registerForm.querySelector('[type="submit"]');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.textContent = 'Đang xử lý...';
                }
                
                // Redirect to login page after a short delay
                setTimeout(() => {
                    window.location.href = 'dangnhap.html';
                }, 2000);
            } else {
                // Scroll to first error
                const firstErrorElement = registerForm.querySelector('.form-group.error');
                if (firstErrorElement) {
                    firstErrorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        });
    }
    
    /**
     * Validate a single input field
     * @param {HTMLElement} input - Input element to validate
     * @returns {boolean} - True if valid, false if invalid
     */
    function validateInput(input) {
        if (!input) return false;
        
        const id = input.id;
        let isValid = true;
        let errorMessage = '';
        
        // Validate based on input type
        switch(id) {
            case 'txtHoTen':
                if (!input.value.trim()) {
                    isValid = false;
                    errorMessage = 'Vui lòng nhập họ và tên';
                } else if (input.value.trim().length < 2) {
                    isValid = false;
                    errorMessage = 'Họ tên phải có ít nhất 2 ký tự';
                }
                break;
                
            case 'txtEmail':
                const emailValue = input.value.trim();
                if (!emailValue) {
                    isValid = false;
                    errorMessage = 'Vui lòng nhập email';
                } else if (!isValidEmail(emailValue)) {
                    isValid = false;
                    errorMessage = 'Email không hợp lệ';
                }
                break;
                
            case 'txtNam':
                const yearValue = input.value.trim();
                if (!yearValue) {
                    isValid = false;
                    errorMessage = 'Vui lòng nhập năm sinh';
                } else if (isNaN(yearValue)) {
                    isValid = false;
                    errorMessage = 'Năm sinh phải là số';
                } else {
                    const currentYear = new Date().getFullYear();
                    if (parseInt(yearValue) < 1900 || parseInt(yearValue) > currentYear) {
                        isValid = false;
                        errorMessage = `Năm sinh phải từ 1900 đến ${currentYear}`;
                    }
                }
                break;
                
            case 'txtTenDN':
                if (!input.value.trim()) {
                    isValid = false;
                    errorMessage = 'Vui lòng nhập tên đăng nhập';
                } else if (input.value.trim().length < 3) {
                    isValid = false;
                    errorMessage = 'Tên đăng nhập phải có ít nhất 3 ký tự';
                } else if (!/^[a-zA-Z0-9_]+$/.test(input.value.trim())) {
                    isValid = false;
                    errorMessage = 'Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới';
                }
                break;
                
            case 'txtMatKhau':
                if (!input.value) {
                    isValid = false;
                    errorMessage = 'Vui lòng nhập mật khẩu';
                } else if (input.value.length < 5) {
                    isValid = false;
                    errorMessage = 'Mật khẩu phải có ít nhất 5 ký tự';
                }
                break;
                
            case 'txtNhapLaiMK':
                if (!input.value) {
                    isValid = false;
                    errorMessage = 'Vui lòng nhập lại mật khẩu';
                } else if (inputs.password && input.value !== inputs.password.value) {
                    isValid = false;
                    errorMessage = 'Mật khẩu nhập lại không khớp';
                }
                break;
        }
        
        // Show or clear error
        if (!isValid) {
            showError(input, errorMessage);
        } else {
            removeError(input);
        }
        
        return isValid;

	}
}
    